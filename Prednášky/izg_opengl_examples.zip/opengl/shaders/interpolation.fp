#version 450

layout(location=0)out vec4 fColor;

in vec3 vColor;
//noperspective in vec3 vColor;

void main(){
  float freq = 0.1;
  bool xStripes = mod(vColor.x,freq)/freq>0.5;
  bool yStripes = mod(vColor.y,freq)/freq>0.5;
  fColor = vec4(xStripes != yStripes);
}
