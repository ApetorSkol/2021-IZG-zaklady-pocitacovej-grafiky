#include <bunnyMethod.hpp>

#include <glm/gtc/type_ptr.hpp>
#include <geGL/StaticCalls.h>
#include <util.hpp>

using namespace ge::gl;


BunnyMethod::BunnyMethod(){
  glCreateBuffers(1,&vbo);
  glNamedBufferData(vbo,sizeof(bunnyVertices),bunnyVertices,GL_DYNAMIC_DRAW);

  glCreateBuffers(1,&ebo);
  glNamedBufferData(ebo,sizeof(bunnyIndices),bunnyIndices,GL_DYNAMIC_DRAW);

  glCreateVertexArrays(1,&vao);

  glVertexArrayAttribFormat (vao,0,3,GL_FLOAT,GL_FALSE,0);
  glVertexArrayVertexBuffer (vao,0,vbo,0,sizeof(BunnyVertex));
  glVertexArrayAttribBinding(vao,0,0);
  glEnableVertexArrayAttrib (vao,0);

  glVertexArrayAttribFormat (vao,1,3,GL_FLOAT,GL_FALSE,0);
  glVertexArrayVertexBuffer (vao,1,vbo,sizeof(float)*(3),sizeof(BunnyVertex));
  glVertexArrayAttribBinding(vao,1,1);
  glEnableVertexArrayAttrib (vao,1);

  glVertexArrayElementBuffer(vao,ebo);

  std::string vsSrc = R".(
  #version 460

  layout(location=0)in vec3 position;
  layout(location=1)in vec3 normal  ;

  out vec3 vNormal;
  out vec3 vPosition;

  uniform mat4 modelMatrix      = mat4(1.f);
  uniform mat4 itModel          = mat4(1.f);
  uniform mat4 projView         = mat4(1.f);

  void main(){

    mat4 mvp = projView * modelMatrix;

    gl_Position = mvp*vec4(position,1);

    vPosition   = vec3(modelMatrix*vec4(position,1));
    vNormal     = vec3(itModel    *vec4(normal  ,0));
  };

  ).";

  std::string fsSrc=
  R".(
  #version 460

  out vec4 fColor;

  uniform vec3 light = vec3(10,10,10);

  uniform vec3 cameraPosition = vec3(0,0,0);

  in vec3 vPosition;
  in vec3 vNormal;

  void main(){

    vec3 N = normalize(vNormal);
    vec3 L = normalize(light-vPosition);
    vec3 diffuseMatrial = vec3(0,0.5,0);
    vec3 lightColor = vec3(1,1,1);
    float dF = clamp(dot(N,L),0,1);
    float aF = 0.2;

    vec3 Id = dF * diffuseMatrial * lightColor;
    vec3 Ia = diffuseMatrial * aF;

    vec3 V = normalize(cameraPosition - vPosition);
    vec3 R = -reflect(V,N);

    float sF = pow(clamp(dot(R,L),0,1),10)*float(dF>0);

    vec3 Is = lightColor * sF;

    vec3 finalColor = Ia + Id + Is;

    fColor = vec4(finalColor,1);
  }

  ).";  

  vs = createShader(GL_VERTEX_SHADER  ,vsSrc);
  fs = createShader(GL_FRAGMENT_SHADER,fsSrc);
  prg = createProgram(vs,fs);

  modelLocation          = glGetUniformLocation(prg,"modelMatrix"   );
  itModelLocation        = glGetUniformLocation(prg,"itModel"       );
  projViewLocation       = glGetUniformLocation(prg,"projView"      );
  cameraPositionLocation = glGetUniformLocation(prg,"cameraPosition");
}

BunnyMethod::~BunnyMethod(){
  glDeleteBuffers(1,&ebo);
  glDeleteBuffers(1,&vbo);
  glDeleteVertexArrays(1,&vao);
  glDeleteShader(fs);
  glDeleteShader(vs);
  glDeleteProgram(prg);
}

void BunnyMethod::draw(glm::mat4 const&view,glm::mat4 const&proj){
  glm::mat4 modelMatrix = glm::mat4(1.f);

  glProgramUniformMatrix4fv(prg,modelLocation   ,1,GL_FALSE,glm::value_ptr(              (            (modelMatrix))));
  glProgramUniformMatrix4fv(prg,itModelLocation ,1,GL_FALSE,glm::value_ptr(glm::transpose(glm::inverse(modelMatrix))));
  glProgramUniformMatrix4fv(prg,projViewLocation,1,GL_FALSE,glm::value_ptr(proj*view));

  glProgramUniform3fv      (prg,cameraPositionLocation,1,glm::value_ptr(glm::vec3(glm::inverse(view)*glm::vec4(0,0,0,1))));

  glBindVertexArray(vao);
  glUseProgram(prg);

  glDrawElements(GL_TRIANGLES,sizeof(bunnyIndices)/sizeof(VertexIndex),GL_UNSIGNED_INT,nullptr);

}
