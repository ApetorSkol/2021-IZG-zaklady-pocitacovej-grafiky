#pragma once

#include <bunny.hpp>
#include <geGL/geGL.h>
#include <glm/glm.hpp>

class BunnyMethod{
  public:
    GLuint vbo;
    GLuint ebo;
    GLuint vao;
    GLuint vs ;
    GLuint fs ;
    GLuint prg;

    GLuint modelLocation         ;
    GLuint itModelLocation       ;
    GLuint projViewLocation      ;
    GLuint cameraPositionLocation;

    BunnyMethod();

    ~BunnyMethod();
    void draw(glm::mat4 const&view,glm::mat4 const&proj);
};
